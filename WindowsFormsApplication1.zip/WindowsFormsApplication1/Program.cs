﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace WindowsFormsApplication1
{
    static class Program
    {

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Thread commThread = new Thread(new ThreadStart(Communication.communicate));
            commThread.IsBackground = true;
            commThread.Start();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

    }

    class Communication
    {
        public static double forward = 0;
        public static double angular = 0;
        public static int motors_enabled = 1;
        public static int PID_enabled = 1;
        static SerialPort serialOut = new SerialPort("COM16", 9600);

        public static void communicate()
        {
            serialOut.Open();
            while (true)
            {
                serialOut.Write(String.Format("F{0:0.000} A{1:0.000} E{2:0} P{3:0}\r", forward, angular, motors_enabled, PID_enabled));
                Thread.Sleep(250);
            }
        }

    }
}
