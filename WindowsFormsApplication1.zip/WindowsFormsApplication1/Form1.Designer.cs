﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.angularTrackBar = new System.Windows.Forms.TrackBar();
            this.speedTrackbar = new System.Windows.Forms.TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.enablePID = new System.Windows.Forms.CheckBox();
            this.enableMotors = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.angularTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.speedTrackbar)).BeginInit();
            this.SuspendLayout();
            // 
            // angularTrackBar
            // 
            this.angularTrackBar.Location = new System.Drawing.Point(141, 242);
            this.angularTrackBar.Maximum = 500;
            this.angularTrackBar.Minimum = -500;
            this.angularTrackBar.Name = "angularTrackBar";
            this.angularTrackBar.Size = new System.Drawing.Size(256, 45);
            this.angularTrackBar.TabIndex = 0;
            this.angularTrackBar.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            // 
            // speedTrackbar
            // 
            this.speedTrackbar.Location = new System.Drawing.Point(1121, 218);
            this.speedTrackbar.Maximum = 500;
            this.speedTrackbar.Minimum = -500;
            this.speedTrackbar.Name = "speedTrackbar";
            this.speedTrackbar.Size = new System.Drawing.Size(114, 45);
            this.speedTrackbar.TabIndex = 1;
            this.speedTrackbar.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            this.speedTrackbar.ValueChanged += new System.EventHandler(this.trackBar2_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(670, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "label5";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 227);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 60);
            this.button1.TabIndex = 9;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(422, 227);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(124, 60);
            this.button2.TabIndex = 10;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1074, 104);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(124, 60);
            this.button3.TabIndex = 11;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1074, 548);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(124, 60);
            this.button4.TabIndex = 12;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(740, 227);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(124, 60);
            this.button5.TabIndex = 13;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // enablePID
            // 
            this.enablePID.AutoSize = true;
            this.enablePID.Location = new System.Drawing.Point(673, 548);
            this.enablePID.Name = "enablePID";
            this.enablePID.Size = new System.Drawing.Size(115, 17);
            this.enablePID.TabIndex = 14;
            this.enablePID.Text = "Enable PID control";
            this.enablePID.UseVisualStyleBackColor = true;
            this.enablePID.CheckedChanged += new System.EventHandler(this.enablePID_CheckedChanged);
            // 
            // enableMotors
            // 
            this.enableMotors.AutoSize = true;
            this.enableMotors.Checked = true;
            this.enableMotors.CheckState = System.Windows.Forms.CheckState.Checked;
            this.enableMotors.Location = new System.Drawing.Point(410, 538);
            this.enableMotors.Name = "enableMotors";
            this.enableMotors.Size = new System.Drawing.Size(94, 17);
            this.enableMotors.TabIndex = 15;
            this.enableMotors.Text = "Enable Motors";
            this.enableMotors.UseVisualStyleBackColor = true;
            this.enableMotors.CheckedChanged += new System.EventHandler(this.enableMotors_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1502, 638);
            this.Controls.Add(this.enableMotors);
            this.Controls.Add(this.enablePID);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.speedTrackbar);
            this.Controls.Add(this.angularTrackBar);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.angularTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.speedTrackbar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar angularTrackBar;
        private System.Windows.Forms.TrackBar speedTrackbar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.CheckBox enablePID;
        private System.Windows.Forms.CheckBox enableMotors;
    }
}

