﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            speedTrackbar.Orientation = Orientation.Vertical;
            speedTrackbar.Height = angularTrackBar.Width;
            angularTrackBar.Value = 5;
            speedTrackbar.Value = 5;
            KeyPreview = true;
            button1.Font = new Font(button1.Font.FontFamily, 14);
            button1.Text = "Speed Left";
            button2.Font = new Font(button2.Font.FontFamily, 14);
            button2.Text = "Speed Right";
            button3.Font = new Font(button3.Font.FontFamily, 14);
            button3.Text = "Speed Up";
            button4.Font = new Font(button4.Font.FontFamily, 14);
            button4.Text = "Speed Down";
            button5.Font = new Font(button5.Font.FontFamily, 14);
            button5.Text = "Reset";
            label5.Font = new Font(label5.Font.FontFamily, 16);  
            label5.Text = "RoboBoat Speed Control";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(angularTrackBar.Value >  angularTrackBar.Minimum){
            angularTrackBar.Value = angularTrackBar.Value - 1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (angularTrackBar.Value < angularTrackBar.Maximum)
            {
                angularTrackBar.Value = angularTrackBar.Value + 1;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (speedTrackbar.Value < speedTrackbar.Maximum)
            {
                speedTrackbar.Value = speedTrackbar.Value + 1;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (speedTrackbar.Value > speedTrackbar.Minimum)
            {
                speedTrackbar.Value = speedTrackbar.Value - 1;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            speedTrackbar.Value = 0;
            angularTrackBar.Value = 0;
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            Communication.angular = ((double)angularTrackBar.Value) / 500.0;
        }

        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            Communication.forward = ((double)speedTrackbar.Value) / 500.0;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void enablePID_CheckedChanged(object sender, EventArgs e)
        {
            Communication.PID_enabled = enablePID.Checked ? 1 : 0;
        }

        private void enableMotors_CheckedChanged(object sender, EventArgs e)
        {
            Communication.motors_enabled = enableMotors.Checked ? 1 : 0;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {

        }

    }
}
